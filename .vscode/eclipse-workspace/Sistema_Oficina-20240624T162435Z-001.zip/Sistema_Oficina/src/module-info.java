/**
 * 
 */
/**
 * @author carlo
 *
 */
module Sistema_Oficina {
	requires java.sql;
	requires java.desktop;
	requires miglayout;
}