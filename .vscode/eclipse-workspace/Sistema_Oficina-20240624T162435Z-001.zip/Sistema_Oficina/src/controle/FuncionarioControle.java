package controle;

import modelo.Funcionario;
import modelo.Servico;
import sistemagrafico.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioControle {
    public String incluiFuncionario(Funcionario car) {

        String retorno = "";
        String sql = "INSERT INTO funcionario (nome, telefone) VALUES (?, ?);";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ps.setString(1, car.getNome());
            ps.setString(2, car.getTelefone());
            if (ps.executeUpdate() > 0) {
                retorno = "Inclusão realizada ";
            } else {
                retorno = "Erro ao incluir";
            }
        } catch (Exception ex) {
            retorno = "Erro ao tentar incluir :" + ex.getMessage();
        }
        return retorno;
    }
    public String ExcluiFuncionario(int i) {

        String retorno = "";
        String sql = "delete from funcionario where codigo=?";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ps.setInt(1, i);
            if (ps.executeUpdate() > 0) {
                retorno = "Exclusão realizada ";
            } else {
                retorno = "Erro ao tentar excluir";
            }
        } catch (Exception ex) {
            retorno = "Erro Excluir " + ex.getMessage();

        }
        return retorno;
    }
    public Servico ListarBuscaFuncionario(String nome) {
        Servico listap = new Servico();
        String sql = "select codigo from funcionario where nome = '" + nome + "';";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Servico servico = new Servico();
                servico.setFuncionario(new Funcionario(rs.getInt("codigo")));
                return servico;
            }

        } catch (Exception ex) {
            System.out.println("Erro (ListarBuscaFuncionario) " + ex.getMessage());
        }
        return listap;
    }
    public Funcionario buscaFuncionarioPorCodigo(int codigo) {
        Funcionario listap = new Funcionario();
        String sql = "select * from funcionario where codigo = ?;";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ps.setInt(1,codigo);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Funcionario cli = new Funcionario();
                cli.setNome(rs.getString("nome"));
                cli.setTelefone(rs.getString("telefone"));
                cli.setCodigo(rs.getInt("codigo"));
                return cli;
            }

        } catch (Exception ex) {
            System.out.println("Erro(BuscarFuncionarioPorCodigo) " + ex.getMessage());
        }
        return listap;
    }
    public int quantidadeSv() {
        int i = 1;
        String sql = "select * from funcionario ";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                i++;
            }

        } catch (Exception ex) {
            System.out.println("Erro "+ex.getMessage());
        }
        return i;
    }
    public List<Funcionario> ListarFuncionario() {
        List<Funcionario> listap = new ArrayList<Funcionario>();
        String sql = "select * from funcionario ";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Funcionario cli = new Funcionario();
                cli.setCodigo(rs.getInt("codigo"));
                cli.setNome(rs.getString("nome"));
                cli.setTelefone(rs.getString("telefone"));
                listap.add(cli);
            }

        } catch (Exception ex) {
            System.out.println("Erro (ListarFuncionario) "+ex.getMessage());
        }
        return listap;
    }

    public String AlterarTelefone(int cod, String telefone){
        String retorno = "";
        System.out.println("ALtera telefone :" + cod +", "+ telefone);
        String sql = "update funcionario\n" +
                "set telefone = '"+telefone+"' where codigo = ?;";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ps.setInt(1,cod);
            retorno = "Alteração realizada!";
            ps.executeQuery();
            return retorno;
        } catch (Exception ex) {
            System.out.println("Erro (AlterarTelefone) "+ex.getMessage());
        }
        return retorno;
    }
    public List<Funcionario> ListarBuscaFuncionarioNome(String nome) {
        List<Funcionario> listap = new ArrayList<Funcionario>();
        String sql = "select *\n" +
                "from funcionario\n" +
                "where nome = '"+nome+"';";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Funcionario fun = new Funcionario();
                fun.setCodigo(rs.getInt("codigo"));
                fun.setNome(rs.getString("nome"));
                fun.setTelefone(rs.getString("telefone"));
                listap.add(fun);
            }
            return listap;

        } catch (Exception ex) {
            System.out.println("Erro (ListarBuscaFuncionarioNome) " + ex.getMessage());
        }
        return listap;
    }
    public int quantidadeSvPC(String nome) {
        int i = 1;
        String sql = "select * from funcionario where nome = '"+nome+"';";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                i++;
            }

        } catch (Exception ex) {
            System.out.println("Erro (quantidadeSvPC)"+ex.getMessage());
        }
        return i;
    }
    public Funcionario buscarFuncionarioPorNome(String nome) {
        String sql = "select * from funcionario where nome = '"+nome+"' ;";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            Funcionario cli = new Funcionario();
            while(rs.next()) {

                cli.setCodigo(rs.getInt("codigo"));

                cli.setNome(rs.getString("nome"));

                cli.setTelefone(rs.getString("telefone"));
            }
            return cli;
        } catch (Exception ex) {
            System.out.println("Erro (ServicoEspecifico)" + ex.getMessage());
        }
        return null;
    }
    public boolean verificar(int codigo) {
		String sql = "select codigo from funcionario where codigo =?;";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ps.setInt(1, codigo);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int cod = rs.getInt("codigo");            	
				if((cod+"").equals("")) {
					return false;
				}
			}
			return true;


		} catch (Exception ex) {
			System.out.println("Erro (VerficiarCliente)"+ex.getMessage());
		}
		return true;
	}


}
