
package controle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import modelo.Cliente;
import modelo.Funcionario;
import modelo.Servico;
import sistemagrafico.Conexao;

public class ServicoControle {

    public String incluiServico(Servico serv) {

        String retorno = "";
        String sql = "INSERT INTO servicos (descricao, codigocliente, modelo, valor, kminicial, ano, codigofuncionario, valorFuncionario) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ps.setString(1, serv.getDescricao());
            ps.setInt(2, serv.getCliente().getCodigo());
            ps.setString(3, serv.getModelo());
            ps.setDouble(4, serv.getValor());
            ps.setString(5, serv.getKminicial());
            ps.setString(6, serv.getAno());
            ps.setInt(7, serv.getFuncionario().getCodigo());
            ps.setString(8, serv.getValorFuncionario()+"");
            System.out.print(serv.getDescricao()+"<- Código \n"
            		+ serv.getDescricao()+"<-Codigo fun");
            if (ps.executeUpdate() > 0) {
                retorno = "Inclusão realizada ";
            } else {
                retorno = "Erro ao incluir";
            }
        } catch (Exception ex) {
            retorno = "Erro ao tentar incluir :" + ex.getMessage();
        }
        return retorno;
    }

    public String ExcluiServico(int i) {

        String retorno = "";
        String sql = "delete from servicos where codigo=?";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ps.setInt(1, i);
            if (ps.executeUpdate() > 0) {
                retorno = "Exclusão realizada ";
            } else {
                retorno = "Erro ao tentar excluir";
            }
        } catch (Exception ex) {
            retorno = "Erro Excluir " + ex.getMessage();

        }
        return retorno;
    }
    public Servico buscaServicoPorCodigo(int codigo) {
        String sql = "select * from servicos where codigo = ? ;";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ps.setInt(1,codigo);
            ResultSet rs = ps.executeQuery();
            Servico servico = new Servico();
            while(rs.next()) {

                servico.setDescricao(rs.getString("descricao"));

                servico.setValor(rs.getDouble("valor"));

                servico.setModelo(rs.getString("modelo"));

                servico.setCodigo(rs.getInt("codigo"));

                servico.setCliente(new Cliente (rs.getInt("codigocliente")));

                servico.setFuncionario(new Funcionario(rs.getInt("codigofuncionario")));

                servico.setAno(rs.getString("ano"));
                
                servico.setValorFuncionario(Double.parseDouble(rs.getString("valorFuncionario")));

            }
            return servico;
        } catch (Exception ex) {
            System.out.println("Erro (ServicoEspecifico)" + ex.getMessage());
        }
        return null;
    }
    public List<Servico> ListarBuscaServicosNome(String nome) {
        List<Servico> listap = new ArrayList<Servico>();
        String sql = "select s.* from servicos s, cliente c where c.nome = '"+nome+"' and s.codigocliente = c.codigo;";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Servico servico = new Servico();
                servico.setDescricao(rs.getString("descricao"));
                servico.setValor(rs.getDouble("valor"));
                servico.setCodigo(rs.getInt("codigo"));
                servico.setModelo(rs.getString("modelo"));
                servico.setCliente(new Cliente (rs.getInt("codigocliente")));
                servico.setFuncionario(new Funcionario(rs.getInt("codigofuncionario")));
                servico.setAno(rs.getString("ano"));
                servico.setValorFuncionario(rs.getDouble("valorfuncionario"));
                listap.add(servico);
            }
            return listap;

        } catch (Exception ex) {
            System.out.println("Erro (ListarBuscaServicosNome) " + ex.getMessage());
        }
        return listap;
    }
    public List<Servico> ListarServicos() {
        List<Servico> listap = new ArrayList<Servico>();
        String sql = "select * from servicos;";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Servico servico = new Servico();
                servico.setModelo(rs.getString("modelo"));
                servico.setDescricao(rs.getString("descricao"));
                servico.setValor(rs.getDouble("valor"));
                servico.setCliente(new Cliente (rs.getInt("codigocliente")));
                servico.setCodigo(rs.getInt("codigo"));
                servico.setFuncionario(new Funcionario(rs.getInt("codigofuncionario")));
                servico.setAno(rs.getString("ano"));
                servico.setValorFuncionario(rs.getDouble("valorfuncionario"));
                listap.add(servico);
            }
            return listap;

        } catch (Exception ex) {
            System.out.println("Erro (ListarServicos)"+ex.getMessage());
        }
        return listap;
    }
    public int quantidadeSv() {
        int i = 1;
        String sql = "select * from servicos ";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                i++;
            }

        } catch (Exception ex) {
            System.out.println("Erro (quantidadeSv) "+ex.getMessage());
        }
        return i;
    }
    public int quantidadeSvPC(String nome) {
        int i = 1;
        String sql = "select * from servicos s, cliente c where c.nome = '"+nome+"' and s.codigocliente = c.codigo";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                i++;
            }

        } catch (Exception ex) {
            System.out.println("Erro (quantidadeSvPC)"+ex.getMessage());
        }
        return i;
    }

    public int buscarCodigo(String nome) {
        String sql = "select codigo from cliente where nome = '"+nome+"'";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            rs.next();
            return rs.getInt("codigo");
        } catch (Exception ex) {
            System.out.println("Erro (buscarCodigo) "+ex.getMessage());
        }
        return 0;
    }
    
    public boolean verificar(int codigo) {
        String sql = "select codigo from servicos;";
        try {
            Connection Con = Conexao.Abrirconexao();
            PreparedStatement ps = Con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
            	int cod = rs.getInt("codigo");
             if((cod+"").equals("")) {
            return false;
             }
            }
            return true;
        

        } catch (Exception ex) {
            System.out.println("Erro (VerficiarServico)"+ex.getMessage());
        }
     return true;
    }
}

