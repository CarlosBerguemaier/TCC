
package controle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import modelo.Cliente;
import modelo.Funcionario;
import sistemagrafico.Conexao;

public class ClienteControle {

	public String incluiCliente(Cliente cli) {

		String retorno = "";
		String sql = "INSERT INTO cliente (nome, telefone) VALUES (?, ?);";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ps.setString(1, cli.getNome());
			ps.setString(2, cli.getTelefone());
			if (ps.executeUpdate() > 0) {
				retorno = "Inclusão realizada ";
			} else {
				retorno = "Erro ao incluir";
			}
		} catch (Exception ex) {
			retorno = "Erro ao tentar incluir :" + ex.getMessage();
		}
		return retorno;
	}
	public Cliente buscarClientePorCodigo(int codigo) {
		Cliente cli = new Cliente();
		String sql = "select nome from cliente where codigo = ?";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ps.setInt(1,codigo);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				cli.setNome(rs.getString("nome"));
			}
			return cli;
		} catch (Exception ex) {
			System.out.println("Erro (buscaClientePorCodigo) " + ex.getMessage());
		}
		return cli;
	}
	public String ExcluiCliente(int i) {

		String retorno = "";
		String sql = "delete from cliente where codigo=?";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ps.setInt(1, i);
			if (ps.executeUpdate() > 0) {
				retorno = "Exclusão realizada ";
			} else {
				retorno = "Erro ao tentar excluir";
			}
		} catch (Exception ex) {
			retorno = "Erro Excluir " + ex.getMessage();

		}
		return retorno;
	}


	public int quantidadeSv() {
		int i = 1;
		String sql = "select * from cliente ";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				i++;
			}

		} catch (Exception ex) {
			System.out.println("Erro "+ex.getMessage());
		}
		return i;
	}

	public List<Cliente> ListarClientes() {
		List<Cliente> listap = new ArrayList<Cliente>();
		String sql = "select * from cliente ";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Cliente cli = new Cliente();
				cli.setCodigo(rs.getInt("codigo"));
				cli.setNome(rs.getString("nome"));
				cli.setTelefone(rs.getString("telefone"));
				listap.add(cli);
			}

		} catch (Exception ex) {
			System.out.println("Erro (ListarClientes)"+ex.getMessage());
		}
		return listap;
	}
	public Cliente BuscaClientePorNome(String nome) {
		Cliente listap = new Cliente();
		String sql = "select codigo from cliente where nome = '"+nome+"';";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				listap.setCodigo(rs.getInt("codigo"));
				return listap;
			}

		} catch (Exception ex) {
			System.out.println("Erro (BuscarClientePorCodigo) " + ex.getMessage());
		}
		return listap;
	}
	public String AlterarTelefone(int cod, String telefone){
		String retorno = "";
		String sql = "update cliente set telefone = '"+telefone+"' where codigo = ?;";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ps.setInt(1,cod);
			retorno = "Alteração realizada!";
			ps.executeQuery();
			return retorno;
		} catch (Exception ex) {
			System.out.println("Erro (AlterarTelefone) "+ex.getMessage());
		}
		return retorno;
	}
	public boolean verificar(int codigo) {
		String sql = "select codigo from cliente where codigo =?;";
		try {
			Connection Con = Conexao.Abrirconexao();
			PreparedStatement ps = Con.prepareStatement(sql);
			ps.setInt(1, codigo);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int cod = rs.getInt("codigo");            	
				if((cod+"").equals("")) {
					return false;
				}
			}
			return true;


		} catch (Exception ex) {
			System.out.println("Erro (VerficiarCliente)"+ex.getMessage());
		}
		return true;
	}
}
