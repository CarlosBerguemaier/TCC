package sistemagrafico;

import java.awt.EventQueue;
import java.awt.GraphicsEnvironment;

import net.miginfocom.swing.MigLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controle.ClienteControle;
import modelo.Cliente;

import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPopupMenu;
import javax.swing.UIManager;

import java.awt.Component;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JDesktopPane;
import java.awt.Toolkit;

public class Sistemagrafico extends JFrame {

	private JPanel telainicial;
	private JLabel menu_servicos1;
	private JMenuBar menuBar;
	private JMenu menu_servicos;
	private JMenu mnservicos;
	private JLabel cadastrar;
	private JMenu mnclientes;
	private JLabel cadastrar_1;
	private JMenu mnfuncionrios;
	private JLabel cadastrar_2;
	private JFrame telaCadastroCliente;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel cadastrar_3;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
					Sistemagrafico frame = new Sistemagrafico();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sistemagrafico() {
		initComponents();
	}
	private void initComponents() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Sistemagrafico.class.getResource("/sistemagrafico/icone.png")));
		setVisible(true);
		setTitle("Sistema Oficina Mecânica");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 845, 573);
		
		menuBar = new JMenuBar();
		menuBar.setFocusCycleRoot(true);
		menuBar.setFocusTraversalKeysEnabled(true);
		menuBar.setFocusTraversalPolicyProvider(true);
		menuBar.setAutoscrolls(true);
		menuBar.setRequestFocusEnabled(false);
		menuBar.setBorderPainted(false);
		menuBar.setForeground(new Color(150, 123, 31));
		menuBar.setBackground(new Color(219, 188, 83));
		setJMenuBar(menuBar);
		
		mnservicos = new JMenu("<html><h1 style=\"color:696969\">Serviços</h1></html>");
		mnservicos.setForeground(new Color(69, 69, 69));
		mnservicos.setBorderPainted(true);
		mnservicos.setBackground(new Color(219, 188, 83));
		menuBar.add(mnservicos);
		
		cadastrar = new JLabel("<html><h1 style=\"color:696969\">Cadastrar</h1></html>");
		cadastrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menucadastroservico();
			}
		});
		cadastrar.setForeground(new Color(69, 69, 69));
		cadastrar.setBackground(new Color(69, 69, 69));
		mnservicos.add(cadastrar);
		
		lblNewLabel_6 = new JLabel("<html><h1 style=\"color:696969\">Excluir\r\n</h1></html>");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menuexcluirservico();
			}
		});
		
		lblNewLabel_7 = new JLabel("<html><h1 style=\"color:696969\">Listar\r\n</h1></html>");
		mnservicos.add(lblNewLabel_7);
		mnservicos.add(lblNewLabel_6);
		mnclientes = new JMenu("<html><h1 style=\"color:696969\">Clientes</h1></html>");
		mnclientes.setForeground(new Color(69, 69, 69));
		mnclientes.setBorderPainted(true);
		mnclientes.setBackground(new Color(69, 69, 69));
		menuBar.add(mnclientes);
		
		cadastrar_1 = new JLabel("<html><h1 style=\"color:696969\">Cadastrar</h1></html>");
		cadastrar_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				showmenu_cadastrocliente();
			}
		});
		cadastrar_1.setForeground(new Color(69, 69, 69));
		cadastrar_1.setBackground(new Color(69, 69, 69));
		mnclientes.add(cadastrar_1);
		
		lblNewLabel = new JLabel("<html><h1 style=\"color:696969\">Excluir\r\n</h1></html>");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menuexluircliente();
			}
		});
		mnclientes.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("<html><h1 style=\"color:696969\">Listar\r\n</h1></html>");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menulistarcliente();
			}
		});
		mnclientes.add(lblNewLabel_1);
		
		lblNewLabel_4 = new JLabel("<html><h1 style=\"color:696969\">Alterar Dados\r\n</h1></html>");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menueditarcliente();
			}
		});
		mnclientes.add(lblNewLabel_4);
		
		mnfuncionrios = new JMenu("<html><h1 style=\"color:696969\">Funcionários</h1></html>");
		mnfuncionrios.setForeground(new Color(69, 69, 69));
		mnfuncionrios.setBorderPainted(true);
		mnfuncionrios.setBackground(new Color(69, 69, 69));
		menuBar.add(mnfuncionrios);
		
		cadastrar_2 = new JLabel("<html><h1 style=\"color:696969\">Cadastrar</h1></html>");
		cadastrar_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menucadastrofuncionario();
			}
		});
		cadastrar_2.setForeground(new Color(69, 69, 69));
		cadastrar_2.setBackground(new Color(69, 69, 69));
		mnfuncionrios.add(cadastrar_2);
		
		cadastrar_3 = new JLabel("<html><h1 style=\"color:696969\">Listar</h1></html>");
		cadastrar_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			show_menulistarfuncionario();
			}
		});
		
		lblNewLabel_2 = new JLabel("<html><h1 style=\"color:696969\">Excluir\r\n</h1></html>");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menuexcluirfuncionario();
			}
		});
		mnfuncionrios.add(lblNewLabel_2);
		cadastrar_3.setForeground(new Color(69, 69, 69)); 
		cadastrar_3.setBackground(new Color(69, 69, 69));
		mnfuncionrios.add(cadastrar_3);
		
		lblNewLabel_5 = new JLabel("<html><h1 style=\"color:696969\">Alterar Dados\r\n</h1></html>");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				show_menueditarfuncionario();
			}
		});
		mnfuncionrios.add(lblNewLabel_5);
		telainicial = new JPanel();
		telainicial.setBackground(new Color(219, 188, 83));
		telainicial.setBorder(new EmptyBorder(5, 5, 5, 5));
		
				setContentPane(telainicial);
		telainicial.setLayout(new MigLayout("", "[grow][][grow]", "[grow][][]"));
		
		menu_servicos = new JMenu("<html><h1 style=\"color:404040;background-color:#696969\">Serviços</h1></html>");
		
		lblNewLabel_3 = new JLabel("Carlos Eduardo Ferreira Berguemaier (55-997074185)");
		telainicial.add(lblNewLabel_3, "cell 0 2 3 1,alignx center");
	}

	private void showmenu_cadastrocliente() { 
		telaCadastroCliente a = new telaCadastroCliente();
		a.setVisible(true);
	}
	private void show_menuexluircliente() {
		telaExluirCliente a = new telaExluirCliente();
		a.setVisible(true);
	}
	private void show_menulistarcliente() {
		telaListarCliente a = new telaListarCliente();
		a.setVisible(true);
	}
	private void show_menueditarcliente() {
		telaEditarCliente a = new telaEditarCliente();
		a.setVisible(true);
	}
	private void show_menucadastrofuncionario(){
		telaCadastroFuncionario a = new telaCadastroFuncionario();
		a.setVisible(true);
	}
	private void show_menuexcluirfuncionario(){
		telaExcluirFuncionario a = new telaExcluirFuncionario();
		a.setVisible(true);
	}
	private void show_menulistarfuncionario() {
		telaListarFuncionario a = new telaListarFuncionario();
		a.setVisible(true);
	}
	private void show_menucadastroservico() {
		telaCadastroServico a = new telaCadastroServico();
		a.setVisible(true);
	}
	private void show_menueditarfuncionario() {
		telaEditarFuncionario a = new telaEditarFuncionario();
		a.setVisible(true);
	}
	private void show_menuexcluirservico(){
		telaExcluirServico a = new telaExcluirServico();
		a.setVisible(true);
	}
	

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
	
	}
