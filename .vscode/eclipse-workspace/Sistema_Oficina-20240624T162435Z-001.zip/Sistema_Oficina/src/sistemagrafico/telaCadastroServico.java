package sistemagrafico;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import controle.ClienteControle;
import controle.FuncionarioControle;
import controle.ServicoControle;
import modelo.Cliente;
import modelo.Funcionario;
import modelo.Servico;

import java.awt.Color;
import java.awt.Toolkit;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Dimension;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class telaCadastroServico extends JFrame {

	private JPanel contentPane;
	private JLabel lblcadastroDeServio;
	private JLabel lblNewLabel;
	private JLabel lblmodeloDoCarro;
	private JLabel lblanoDoModelo;
	private JLabel lbldescrio;
	private JLabel lblvalorDaMo;
	private JLabel lblquilometragem;
	private JLabel lblfuncionrio;
	private JTextField fieldNome;
	private JTextField fieldModelo;
	private JTextField fieldAno;
	private JTextField fieldDescricao;
	private JTextField fieldValor;
	private JTextField fieldKM;
	private JTextField fieldFuncionario;
	private JButton botao;
	private JLabel lbldata;
	private JTextField fieldData;
	private JLabel lblvalorParaO;
	private JTextField fieldValorFun;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
					telaCadastroServico frame = new telaCadastroServico();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaCadastroServico() {
		initComponents();
	}
	private void initComponents() {
		setTitle("Cadastro de Serviço");
		setIconImage(Toolkit.getDefaultToolkit().getImage(telaCadastroServico.class.getResource("/sistemagrafico/icone.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 806, 694);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(219, 188, 83));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
				setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][][grow][grow]", "[][][][][][][][][][][][][grow]"));
		
		lblcadastroDeServio = new JLabel("<html><h1 style=\"font-size:40;background-color:#DBBC53; color:#8A602D\">Cadastro de Serviço\r\n</h1></html>");
		contentPane.add(lblcadastroDeServio, "cell 1 1 2 1,alignx center");
		
		lblNewLabel = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Nome do Cliente: \r\n</h1>\r\n</html>");
		contentPane.add(lblNewLabel, "cell 1 2,alignx trailing");
		
		fieldNome = new JTextField();
		fieldNome.setPreferredSize(new Dimension(50, 20));
		fieldNome.setMinimumSize(new Dimension(40, 30));
		fieldNome.setMaximumSize(new Dimension(900, 100));
		fieldNome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldNome.setColumns(10);
		contentPane.add(fieldNome, "cell 2 2,growx");
		
		lblmodeloDoCarro = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Modelo do carro: \r\n</h1>\r\n</html>");
		contentPane.add(lblmodeloDoCarro, "cell 1 3,alignx trailing");
		
		fieldModelo = new JTextField();
		fieldModelo.setPreferredSize(new Dimension(50, 20));
		fieldModelo.setMinimumSize(new Dimension(40, 30));
		fieldModelo.setMaximumSize(new Dimension(900, 100));
		fieldModelo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldModelo.setColumns(10);
		contentPane.add(fieldModelo, "cell 2 3,growx");
		
		lblanoDoModelo = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Ano do Modelo : \r\n</h1>\r\n</html>");
		contentPane.add(lblanoDoModelo, "cell 1 4,alignx trailing");
		
		fieldAno = new JTextField();
		fieldAno.setPreferredSize(new Dimension(50, 20));
		fieldAno.setMinimumSize(new Dimension(40, 30));
		fieldAno.setMaximumSize(new Dimension(900, 100));
		fieldAno.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldAno.setColumns(10);
		contentPane.add(fieldAno, "cell 2 4,growx");
		
		lbldescrio = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Descrição : \r\n</h1>\r\n</html>");
		contentPane.add(lbldescrio, "cell 1 5,alignx trailing");
		
		fieldDescricao = new JTextField();
		fieldDescricao.setPreferredSize(new Dimension(50, 20));
		fieldDescricao.setMinimumSize(new Dimension(40, 30));
		fieldDescricao.setMaximumSize(new Dimension(900, 100));
		fieldDescricao.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldDescricao.setColumns(10);
		contentPane.add(fieldDescricao, "cell 2 5,growx");
		
		lblvalorDaMo = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Valor da Mão de obra: \r\n</h1>\r\n</html>");
		contentPane.add(lblvalorDaMo, "cell 1 6,alignx trailing");
		
		fieldValor = new JTextField();
		fieldValor.setPreferredSize(new Dimension(50, 20));
		fieldValor.setMinimumSize(new Dimension(40, 30));
		fieldValor.setMaximumSize(new Dimension(900, 100));
		fieldValor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldValor.setColumns(10);
		contentPane.add(fieldValor, "cell 2 6,growx");
		
		lblquilometragem = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Quilometragem: \r\n</h1>\r\n</html>");
		contentPane.add(lblquilometragem, "cell 1 7,alignx trailing");
		
		fieldKM = new JTextField();
		fieldKM.setPreferredSize(new Dimension(50, 20));
		fieldKM.setMinimumSize(new Dimension(40, 30));
		fieldKM.setMaximumSize(new Dimension(900, 100));
		fieldKM.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldKM.setColumns(10);
		contentPane.add(fieldKM, "cell 2 7,growx");
		
		lblfuncionrio = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Funcionário: \r\n</h1>\r\n</html>");
		contentPane.add(lblfuncionrio, "cell 1 8,alignx trailing");
		
		fieldFuncionario = new JTextField();
		fieldFuncionario.setPreferredSize(new Dimension(50, 20));
		fieldFuncionario.setMinimumSize(new Dimension(40, 30));
		fieldFuncionario.setMaximumSize(new Dimension(900, 100));
		fieldFuncionario.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldFuncionario.setColumns(10);
		contentPane.add(fieldFuncionario, "cell 2 8,growx");
		
		lblvalorParaO = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Valor para o Funcionario: \r\n</h1>\r\n</html>");
		contentPane.add(lblvalorParaO, "cell 1 9,alignx trailing");
		
		fieldValorFun = new JTextField();
		fieldValorFun.setPreferredSize(new Dimension(50, 20));
		fieldValorFun.setMinimumSize(new Dimension(40, 30));
		fieldValorFun.setMaximumSize(new Dimension(900, 100));
		fieldValorFun.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldValorFun.setColumns(10);
		contentPane.add(fieldValorFun, "cell 2 9,growx");
		
		lbldata = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Data: \r\n</h1>\r\n</html>");
		contentPane.add(lbldata, "cell 1 10,alignx trailing");
		
		fieldData = new JTextField();
		fieldData.setPreferredSize(new Dimension(50, 20));
		fieldData.setMinimumSize(new Dimension(40, 30));
		fieldData.setMaximumSize(new Dimension(900, 100));
		fieldData.setFont(new Font("Tahoma", Font.PLAIN, 20));
		fieldData.setColumns(10);
		contentPane.add(fieldData, "cell 2 10,growx");
		
		botao = new JButton("<html><h1 style=\"font-size:20; color:#8A602D\">Incluir\r\n</h1></html>");
		botao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				incluirServico();
			}
		});
		botao.setForeground(new Color(184, 143, 61));
		botao.setBackground(new Color(184, 143, 61));
		contentPane.add(botao, "cell 1 11 2 1,alignx center");
	}
	
	public void incluirServico() {
        try {
        	ClienteControle cliC = new ClienteControle();
        	FuncionarioControle funC = new FuncionarioControle();
        	Cliente cli  = cliC.BuscaClientePorNome(fieldNome.getText());
        	Funcionario fun = funC.buscarFuncionarioPorNome(fieldFuncionario.getText());
            Servico servico = new Servico();
            servico.setCliente(new Cliente(fieldNome.getText()));
            servico.setModelo(fieldModelo.getText());
            servico.setAno(fieldAno.getText());
            servico.setDescricao(fieldDescricao.getText());
            servico.setValor(Double.parseDouble(fieldValor.getText()));
            servico.setKminicial(fieldKM.getText());
            servico.setFuncionario(new Funcionario(fieldFuncionario.getText()));
            servico.setValorFuncionario(Double.parseDouble(fieldValorFun.getText()));
            
            ServicoControle servC = new ServicoControle();
                    servC.incluiServico(servico);
                    JOptionPane.showMessageDialog(null, "Inclusão confirmada!", "Inclusão", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
                    e.getMessage();
           
        }
	  }

}
