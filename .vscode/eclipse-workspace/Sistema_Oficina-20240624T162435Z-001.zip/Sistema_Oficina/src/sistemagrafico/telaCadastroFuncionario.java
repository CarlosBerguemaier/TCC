package sistemagrafico;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import controle.ClienteControle;
import controle.FuncionarioControle;
import modelo.Cliente;
import modelo.Funcionario;
import net.miginfocom.swing.MigLayout;
import java.awt.Toolkit;

public class telaCadastroFuncionario extends JFrame {

		private JPanel contentPane;
		private JLabel lblNewLabel;
		private JLabel lblNewLabel_1;
		private JLabel lblNewLabel_2;
		private JTextField fieldNome;
		private JButton botao;
		private JTextField fieldTelefone;

		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
						telaCadastroFuncionario frame = new telaCadastroFuncionario();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the frame.
		 */
		public telaCadastroFuncionario() {
			initComponents();
		}
		private void initComponents() {
			setIconImage(Toolkit.getDefaultToolkit().getImage(telaCadastroFuncionario.class.getResource("/sistemagrafico/icone.png")));
			setTitle("Cadastro de Funcionários");
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setBounds(100, 100, 625, 313);
			contentPane = new JPanel();
			contentPane.setMaximumSize(new Dimension(40, 30));
			contentPane.setMinimumSize(new Dimension(40, 30));
			contentPane.setBackground(new Color(219,188,83));
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			
					setContentPane(contentPane);
			contentPane.setLayout(new MigLayout("", "[grow][][grow][grow]", "[][][][]"));
			
			lblNewLabel = new JLabel("<html><h1 style=\"font-size:40;background-color:#DBBC53; color:#8A602D\">Cadastro de Funcionários\r\n</h1></html>");
			contentPane.add(lblNewLabel, "cell 1 0 2 1,alignx center");
			
			lblNewLabel_1 = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Nome : \r\n</h1>\r\n</html>");
			contentPane.add(lblNewLabel_1, "cell 1 1,alignx trailing");
			
			fieldNome = new JTextField();
			fieldNome.setMaximumSize(new Dimension(900, 100));
			fieldNome.setFont(new Font("Tahoma", Font.PLAIN, 20));
			fieldNome.setPreferredSize(new Dimension(50, 20));
			fieldNome.setMinimumSize(new Dimension(40, 30));
			contentPane.add(fieldNome, "cell 2 1,growx");
			fieldNome.setColumns(10);
			
			lblNewLabel_2 = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Telefone :  \r\n</h1>\r\n\r\n\r\r\n</html>");
			contentPane.add(lblNewLabel_2, "cell 1 2,alignx trailing");
			
			fieldTelefone = new JTextField();
			fieldTelefone.setPreferredSize(new Dimension(50, 20));
			fieldTelefone.setMinimumSize(new Dimension(40, 30));
			fieldTelefone.setMaximumSize(new Dimension(900, 100));
			fieldTelefone.setFont(new Font("Tahoma", Font.PLAIN, 20));
			fieldTelefone.setColumns(10);
			contentPane.add(fieldTelefone, "cell 2 2,growx");
			
			botao = new JButton("<html><h1 style=\"font-size:20; color:#8A602D\">Incluir\r\n</h1></html>");
			botao.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
	            incluirCliente();
				}
			});
			botao.setForeground(new Color(184, 143, 61));
			botao.setBackground(new Color(184, 143, 61));
			contentPane.add(botao, "cell 1 3 2 1,alignx center");
		}
		
		public void incluirCliente() {
	            try {
	                Funcionario funcionario = new Funcionario();
	                funcionario.setNome(fieldNome.getText());
	                funcionario.setTelefone(fieldTelefone.getText());
	                FuncionarioControle prodC = new FuncionarioControle();
	                        prodC.incluiFuncionario(funcionario);
	                        JOptionPane.showMessageDialog(null, "Inclusão confirmada!", "Inclusão", JOptionPane.INFORMATION_MESSAGE);
	            } catch (Exception e) {
	                        e.getMessage();
	               
	            }
			  }
	    }


