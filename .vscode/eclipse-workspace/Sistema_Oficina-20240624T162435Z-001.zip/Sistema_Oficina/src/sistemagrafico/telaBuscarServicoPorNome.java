package sistemagrafico;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import java.awt.Dimension;
import javax.swing.table.DefaultTableModel;

import controle.ClienteControle;
import controle.FuncionarioControle;
import controle.ServicoControle;
import modelo.Cliente;
import modelo.Funcionario;
import modelo.Servico;

import javax.swing.JScrollPane;

import java.awt.Button;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class telaBuscarServicoPorNome extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel titulo;
	private JLabel labelDigiteOCodigo;
	private JTextField fieldNome;
	private JButton botaoBuscar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaBuscarServicoPorNome frame = new telaBuscarServicoPorNome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaBuscarServicoPorNome() {
		initComponents();
	}
	private void initComponents() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(telaExcluirFuncionario.class.getResource("/sistemagrafico/icone.png")));
		setTitle("Buscar serviços por nome de cliente");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1174, 691);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(219, 188, 83));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
				setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][200][][][][][200][grow]", "[][][][][]"));
	
		titulo = new JLabel("<html><h1 style=\"font-size:40;background-color:#DBBC53; color:#8A602D\">Buscar Serviço\r\n</h1></html>");
		contentPane.add(titulo, "cell 2 0 4 1,alignx center");
		
		
		labelDigiteOCodigo = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Digite o nome do cliente aqui: \r\n</h1></html>");
		contentPane.add(labelDigiteOCodigo, "cell 2 1,alignx right");
		
		fieldNome = new JTextField();
		fieldNome.setMinimumSize(new Dimension(200, 30));
		fieldNome.setMaximumSize(new Dimension(200, 40));
		contentPane.add(fieldNome, "cell 3 1 2 1,alignx left");
		fieldNome.setColumns(10);
		
		botaoBuscar = new JButton("<html><h1 style=\"font-size:20; color:#8A602D\">Buscar\r\n</h1></html>");
		
			contentPane.add(botaoBuscar, "cell 5 1,alignx center");
			
		
		scrollPane = new JScrollPane();
		scrollPane.setMinimumSize(new Dimension(25, 25));
		scrollPane.setBackground(new Color(240, 240, 240));
		contentPane.add(scrollPane, "cell 1 2 6 1,grow");
		
		table = new JTable();
		table.setEnabled(false);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.print("Cliquei");
			}
		});
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"C\u00F3digo", "Nome Cliente", "Funcion\u00E1rio", "Valor Funcionario", "Descri\u00E7\u00E3o", "Data", "Valor Final"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(45);
		table.getColumnModel().getColumn(0).setMaxWidth(60);
		table.getColumnModel().getColumn(1).setPreferredWidth(150);
		table.getColumnModel().getColumn(1).setMinWidth(150);
		table.getColumnModel().getColumn(1).setMaxWidth(300);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(2).setMinWidth(10);
		table.getColumnModel().getColumn(2).setMaxWidth(100);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setMinWidth(10);
		table.getColumnModel().getColumn(3).setMaxWidth(100);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		table.getColumnModel().getColumn(4).setMinWidth(200);
		table.getColumnModel().getColumn(5).setPreferredWidth(70);
		table.getColumnModel().getColumn(5).setMaxWidth(70);
		table.getColumnModel().getColumn(6).setPreferredWidth(100);
		table.getColumnModel().getColumn(6).setMinWidth(10);
		table.getColumnModel().getColumn(6).setMaxWidth(100);
		table.setSize(new Dimension(5, 5));
		DefaultTableModel modelo = (DefaultTableModel) table.getModel();
		botaoBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limparTabela(modelo);
				criarTabela(modelo);
			}
		});
	}
		
	public void limparTabela(DefaultTableModel modelo) {
		Object[] rowData = {};
		for(int i = 0; i<modelo.getRowCount();i++) {
		modelo.setRowCount(0);
		}
	}
	
	public void criarTabela(DefaultTableModel modelo) {
		ServicoControle cc = new ServicoControle();
		List<Servico> listaservicos = cc.ListarBuscaServicosNome(fieldNome.getText());
		for(Servico ca: listaservicos) {
		Object[] rowData = {ca.getCodigo(),ca.getCliente().getNome(),ca.getFuncionario().getNome(),ca.getValorFuncionario(),ca.getModelo()+" - "+ca.getDescricao(),ca.getValor(),};
		modelo.addRow(rowData);
	}
	}
		}

