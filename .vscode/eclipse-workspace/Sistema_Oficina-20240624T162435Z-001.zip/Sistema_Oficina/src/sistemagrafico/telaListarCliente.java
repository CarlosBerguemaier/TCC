package sistemagrafico;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import java.awt.Dimension;
import javax.swing.table.DefaultTableModel;

import controle.ClienteControle;
import modelo.Cliente;

import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Toolkit;

public class telaListarCliente extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaListarCliente frame = new telaListarCliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaListarCliente() {
		initComponents();
	}
	private void initComponents() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(telaListarCliente.class.getResource("/sistemagrafico/icone.png")));
		setTitle("Lista de Clientes");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 852, 691);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(219, 188, 83));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
				setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][][grow]", "[][][][]"));
	
		lblNewLabel = new JLabel("<html><h1 style=\"font-size:40;background-color:#DBBC53; color:#8A602D\">Todos os Clientes\r\n</h1></html>");
		contentPane.add(lblNewLabel, "cell 1 0,alignx center");
		
		scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(240, 240, 240));
		contentPane.add(scrollPane, "cell 1 2,alignx center,growy");
		
		table = new JTable();
		table.setEnabled(false);
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"C\u00F3digo", "Nome", "Telefone"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(45);
		table.getColumnModel().getColumn(0).setMaxWidth(60);
		table.getColumnModel().getColumn(1).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setMinWidth(100);
		table.setSize(new Dimension(2, 2));
		DefaultTableModel modelo = (DefaultTableModel) table.getModel();
		criarTabela(modelo);
		
	}

	public void criarTabela(DefaultTableModel modelo) {
		
		ClienteControle cc = new ClienteControle();
		List<Cliente> listacliente = cc.ListarClientes();
		for(Cliente ca: listacliente) {
		Object[] rowData = {ca.getCodigo(),ca.getNome(),ca.getTelefone()};
		modelo.addRow(rowData);
	}
	}
		}

