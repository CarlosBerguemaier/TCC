package sistemagrafico;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import java.awt.Dimension;
import javax.swing.table.DefaultTableModel;

import controle.ClienteControle;
import modelo.Cliente;

import javax.swing.JScrollPane;

import java.awt.Button;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class telaEditarCliente extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel titulo;
	private JLabel labelDigiteOCodigo;
	private JTextField fieldCodigo;
	private JButton botaoExcluir;
	private JLabel lbldigiteONovo;
	private JTextField fieldNumero;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaEditarCliente frame = new telaEditarCliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaEditarCliente() {
		initComponents();
	}
	private void initComponents() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(telaExluirCliente.class.getResource("/sistemagrafico/icone.png")));
		setTitle("Alterar dados do Cliente\r\n");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 889, 778);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(219, 188, 83));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
				setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][][grow][][grow]", "[grow][][][][][][][grow][-19.00]"));
	
		titulo = new JLabel("<html><h1 style=\"font-size:40;background-color:#DBBC53; color:#8A602D\">Editar dados do Cliente\r\n</h1></html>");
		contentPane.add(titulo, "cell 1 1 3 1,alignx center");
		
		scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(240, 240, 240));
		contentPane.add(scrollPane, "cell 1 3 3 1,alignx center,growy");
		
		table = new JTable();
		table.setEnabled(false);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.print("Cliquei");
			}
		});
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"C\u00F3digo", "Nome", "Telefone"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(45);
		table.getColumnModel().getColumn(0).setMaxWidth(60);
		table.getColumnModel().getColumn(1).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setMinWidth(100);
		table.setSize(new Dimension(2, 2));
		DefaultTableModel modelo = (DefaultTableModel) table.getModel();
		criarTabela(modelo);
		
		
		labelDigiteOCodigo = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Digite o Código do cliente aqui: \r\n</h1></html>");
		contentPane.add(labelDigiteOCodigo, "cell 1 4,alignx right");
		
		fieldCodigo = new JTextField();
		fieldCodigo.setMinimumSize(new Dimension(40, 30));
		fieldCodigo.setMaximumSize(new Dimension(40, 40));
		contentPane.add(fieldCodigo, "cell 2 4,alignx left");
		fieldCodigo.setColumns(10);
		
		lbldigiteONovo = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Digite o novo Número do cliente aqui: \r\n</h1></html>");
		contentPane.add(lbldigiteONovo, "cell 1 5,alignx trailing");
		
		botaoExcluir = new JButton("<html><h1 style=\"font-size:20; color:#8A602D\">Editar\r\n\r\n</h1></html>");
		botaoExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cliqueParaAlterar();
			}
		});
		
		fieldNumero = new JTextField();
		fieldNumero.setMinimumSize(new Dimension(90, 30));
		fieldNumero.setMaximumSize(new Dimension(200, 40));
		fieldNumero.setColumns(10);
		contentPane.add(fieldNumero, "cell 2 5 2 1,growx");
		contentPane.add(botaoExcluir, "cell 1 6 3 1,alignx center");
	}
	public void cliqueParaAlterar() {
		ClienteControle cc = new ClienteControle();
		System.out.print(Integer.parseInt(fieldCodigo.getText()));
		if(fieldCodigo.getText().equals("")||!cc.verificar(Integer.parseInt(fieldCodigo.getText()))) {
			JOptionPane.showMessageDialog(null, "Codigo não encontrado!", "Exclusão",
					JOptionPane.ERROR_MESSAGE);
		}else {
		Cliente cli = cc.buscarClientePorCodigo(Integer.parseInt(fieldCodigo.getText()));
		int resposta = JOptionPane.showConfirmDialog(null, "Deseja mesmo alterar o telefone do cliente "+cli.getNome()+"?","Confirmando...", JOptionPane.YES_NO_CANCEL_OPTION);
				if(resposta == JOptionPane.YES_OPTION) {
				cc.AlterarTelefone(Integer.parseInt(fieldCodigo.getText()), fieldNumero.getText());
				JOptionPane.showMessageDialog(null, "Alteração confirmada!", "Alteração", JOptionPane.INFORMATION_MESSAGE);
				}
				if(resposta == JOptionPane.NO_OPTION) {
				JOptionPane.showMessageDialog(null, "Alteração cancelada!", "Alteração",
				JOptionPane.ERROR_MESSAGE);
				}
				if(resposta == JOptionPane.CANCEL_OPTION) {
				JOptionPane.showMessageDialog(null, "Alterando...", "Alteração",
				JOptionPane.WARNING_MESSAGE);
				}
		}
			}
		

	public void criarTabela(DefaultTableModel modelo) {
		ClienteControle cc = new ClienteControle();
		List<Cliente> listacliente = cc.ListarClientes();
		for(Cliente ca: listacliente) {
		Object[] rowData = {ca.getCodigo(),ca.getNome(),ca.getTelefone()};
		modelo.addRow(rowData);
	}
	}
		}

