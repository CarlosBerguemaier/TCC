package sistemagrafico;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import java.awt.Dimension;
import javax.swing.table.DefaultTableModel;

import controle.ClienteControle;
import controle.FuncionarioControle;
import modelo.Cliente;
import modelo.Funcionario;

import javax.swing.JScrollPane;

import java.awt.Button;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class telaExcluirFuncionario extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel titulo;
	private JLabel labelDigiteOCodigo;
	private JTextField fieldCodigo;
	private JButton botaoExcluir;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaExcluirFuncionario frame = new telaExcluirFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaExcluirFuncionario() {
		initComponents();
	}
	private void initComponents() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(telaExcluirFuncionario.class.getResource("/sistemagrafico/icone.png")));
		setTitle("Exlcuir Clientes");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 852, 691);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(219, 188, 83));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
				setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[grow][][][][grow]", "[][][][][]"));
	
		titulo = new JLabel("<html><h1 style=\"font-size:40;background-color:#DBBC53; color:#8A602D\">Excluir Funcionário\n</h1></html>");
		contentPane.add(titulo, "cell 1 0 3 1,alignx center");
		
		scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(240, 240, 240));
		contentPane.add(scrollPane, "cell 1 2 3 1,alignx center,growy");
		
		table = new JTable();
		table.setEnabled(false);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.print("Cliquei");
			}
		});
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"C\u00F3digo", "Nome", "Telefone"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(45);
		table.getColumnModel().getColumn(0).setMaxWidth(60);
		table.getColumnModel().getColumn(1).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setMinWidth(100);
		table.setSize(new Dimension(2, 2));
		DefaultTableModel modelo = (DefaultTableModel) table.getModel();
		criarTabela(modelo);
		
		
		labelDigiteOCodigo = new JLabel("<html><h1 style=\"font-size:20;background-color:#DBBC53; color:#8A602D\">Digite o Código do funcionário aqui: \r\n</h1></html>");
		contentPane.add(labelDigiteOCodigo, "cell 1 3,alignx right");
		
		fieldCodigo = new JTextField();
		fieldCodigo.setMinimumSize(new Dimension(40, 30));
		fieldCodigo.setMaximumSize(new Dimension(40, 40));
		contentPane.add(fieldCodigo, "cell 2 3,alignx left");
		fieldCodigo.setColumns(10);
		
		botaoExcluir = new JButton("<html><h1 style=\"font-size:20; color:#8A602D\">Excluir\r\n</h1></html>");
		botaoExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cliqueParaExluir();
			}
		});
		contentPane.add(botaoExcluir, "cell 3 3,alignx center");
	}
	public void cliqueParaExluir() {
		FuncionarioControle cc = new FuncionarioControle();

		if( fieldCodigo.getText().equals("")||!cc.verificar(Integer.parseInt(fieldCodigo.getText()))) {
			JOptionPane.showMessageDialog(null, "Codigo não encontrado!", "Exclusão",
					JOptionPane.ERROR_MESSAGE);
		}else {
		Funcionario cli = cc.buscaFuncionarioPorCodigo(Integer.parseInt(fieldCodigo.getText()));
		int resposta = JOptionPane.showConfirmDialog(null, "Deseja mesmo excluir o funcionário "+cli.getNome()+"?","Confirmando...", JOptionPane.YES_NO_CANCEL_OPTION);
				if(resposta == JOptionPane.YES_OPTION) {
				cc.ExcluiFuncionario(Integer.parseInt(fieldCodigo.getText()));
				JOptionPane.showMessageDialog(null, "Exclusão confirmada!", "Exclusão", JOptionPane.INFORMATION_MESSAGE);
				}
				if(resposta == JOptionPane.NO_OPTION) {
				JOptionPane.showMessageDialog(null, "Exlcusão cancelada!", "Exclusão",
				JOptionPane.ERROR_MESSAGE);
				}
				if(resposta == JOptionPane.CANCEL_OPTION) {
				JOptionPane.showMessageDialog(null, "Cancelando...", "Exclusão",
				JOptionPane.WARNING_MESSAGE);
				}
		}
			}
		

	public void criarTabela(DefaultTableModel modelo) {
		
		FuncionarioControle cc = new FuncionarioControle();
		List<Funcionario> listacliente = cc.ListarFuncionario();
		for(Funcionario ca: listacliente) {
		Object[] rowData = {ca.getCodigo(),ca.getNome(),ca.getTelefone()};
		modelo.addRow(rowData);
	}
	}
		}

