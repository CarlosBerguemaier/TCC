package modelo;

import controle.ClienteControle;
import controle.FuncionarioControle;

public class Cliente {
    private String nome;
    private int codigo;
    private String telefone;
    private String descricao;
    
    public Cliente() {}
    
    public Cliente(int codigo) {
    	this.codigo=codigo;
    	ClienteControle fc = new ClienteControle();
    	Cliente f1 = fc.buscarClientePorCodigo(codigo);
    	this.nome = f1.getNome();
    	this.telefone = f1.getTelefone();
    }


    public Cliente(String text) {
	  this.nome = text;
	  ClienteControle fc = new ClienteControle();
    Cliente f1 = fc.BuscaClientePorNome(text);
    	this.telefone = f1.getTelefone();
    	this.codigo = f1.getCodigo();
  	
	}
	public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
