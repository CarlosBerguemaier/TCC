package modelo;

public class Servico {
    private boolean finalizado;
    private String ano;
    private Funcionario funcionario;
    private Cliente cliente;
    private String descricao;
    private int codigo;
    private String modelo;
    private double valor;
    private double valorFuncionario;
    private String kminicial;
    private String kmfinal;


    public boolean isFinalizado() {
        return finalizado;
    }
    
    public double getValorFuncionario() {
		return valorFuncionario;
	}

	public void setValorFuncionario(double valorFuncionario) {
		this.valorFuncionario = valorFuncionario;
	}

	public String getKmfinal() {
		return kmfinal;
	}

	public void setKmfinal(String kmfinal) {
		this.finalizado = true;
		this.kmfinal = kmfinal;
	}

	public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }
    public void setFinalizado(boolean finalizado) {
        this.finalizado = finalizado;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Servico() {
        this.finalizado = false;
    }

    public String getKminicial() {
        return kminicial;
    }

    public void setKminicial(String kminicial) {
        this.kminicial = kminicial;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Cliente getCliente() {
        return cliente;
    }
    public void setCliente(Cliente cliente) {
       this.cliente = cliente;
    }

    public void setCodigocliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String toString(){
        return this.modelo;
    }
}
