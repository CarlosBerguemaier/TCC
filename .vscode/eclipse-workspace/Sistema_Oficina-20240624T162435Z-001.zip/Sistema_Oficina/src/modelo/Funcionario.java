package modelo;

import controle.FuncionarioControle;

public class Funcionario {
    private String nome;
    private String telefone;
    private int codigo;

    public String getNome() {
        return nome;
    }

    public Funcionario() {
    }
    public Funcionario(int codigo) {
    	this.codigo=codigo;
    	FuncionarioControle fc = new FuncionarioControle();
    	Funcionario f1 = fc.buscaFuncionarioPorCodigo(codigo);
    	this.nome = f1.getNome();
    	this.telefone = f1.getTelefone();
    }

    public Funcionario(String nome) {
    	FuncionarioControle fc = new FuncionarioControle();
    	Funcionario f1 = fc.buscarFuncionarioPorNome(nome);
    	this.codigo = f1.getCodigo();
    	this.telefone = f1.getTelefone();
	}

	public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String toString() {
    	return this.nome+", "+this.telefone+", "+this.codigo;
    }
}
