package Oficina;

public class Carros {
private String Marca;
private String Modelo;
private String Ano;
private String Placa;
private String Dono;

public Carros(String placa) {
	super();
	this.Placa = placa;
}
public String getMarca() {
	return Marca;
}
public void setMarca(String marca) {
	Marca = marca;
}
public String getModelo() {
	return Modelo;
}
public void setModelo(String modelo) {
	Modelo = modelo;
}
public String getAno() {
	return Ano;
}
public void setAno(String ano) {
	Ano = ano;
}
public String getPlaca() {
	return Placa;
}
public void setPlaca(String placa) {
	Placa = placa;
}
public String getDono() {
	return Dono;
}
public void setDono(String dono) {
	Dono = dono;
}

public void AddMapaCar(Carros carro) {
	Menu.CarrosMap.put(this.Placa, carro);}

public String toString() {
	return Marca+","+Modelo+","+Ano+"\nPlaca:"+Placa;
}
}
