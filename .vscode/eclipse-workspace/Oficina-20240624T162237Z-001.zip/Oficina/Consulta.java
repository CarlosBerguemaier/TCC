package Oficina;

import java.util.HashMap;
import java.util.Map;

public class Consulta {
	private int NmrConsulta;
	
	
    public Consulta() {
    	NmrConsulta = 1;
    }
    
	public void MapaAdd(String nome,Clientes cli01) {
		Menu.ClientesMap.put(nome, cli01);
	}
	
	public String Consultar(Clientes cliente){
		if (cliente != null) {
		   return "Nome: " + cliente.getNome();}	
  return "O nome nao foi encontrado!";
	}
	
	public void MapaAddCar(String nome,Carros car01) {
		Menu.CarrosMap.put(nome, car01);
	}
	
}
