package Oficina;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javax.swing.JOptionPane;

	

public class Menu {
static Map<String, Clientes> ClientesMap = new HashMap<>();
static Map<String, Carros> CarrosMap = new HashMap<>();
static Map<String, Servicos> ServicosMap = new HashMap<>();

public void MapaAdd(String nome,Clientes cliente) {
		ClientesMap.put(nome, cliente);
	}
	



 public static void main(String[] args) {
	 Scanner e = new Scanner(System.in);
	 int fim = 0;
	while(fim!=4) {
		
		String op = JOptionPane.showInputDialog(null,"MENU\n"
		 		+ "1- CADASTRAR CLIENTE\n"
		 		+ "2- CADASTRAR VEICULO\n"
		 		+ "3- CADASTRAR SERVICO\n"
		 		+ "4- CONSULTAR CLIENTES\n"
		 		+ "5- CONSULTAR CARROS\n"
		 		+ "6- ADICIONAR DADOS CLIENTES\n"
		 		+ "7- ADICIONAR DADOS VEICULOS\n"
		 		+ "8- CONSULTAR SERVICO\n"
		 		+ "9- SAIR");
	 switch (op){
		 case "1": 
		    Clientes cli01 = new Clientes(JOptionPane.showInputDialog(null, "Digite o nome do cliente"));
		    cli01.AddMapa(cli01);
		    break;
		 case"2":
			 Carros car01 = new Carros(JOptionPane.showInputDialog(null,"Digite a Placa do carro:"));
			car01.AddMapaCar(car01);
			 break;
		 case "3":
			    String nmr = JOptionPane.showInputDialog(null, "Digite o numero do serviço: ");

				String placas = JOptionPane.showInputDialog(null, "Digite a placa do carro: ");
				Carros cars =CarrosMap.get(placas);
				String dono = JOptionPane.showInputDialog(null, "Digite o dono do carro: ");
			    Clientes donos =ClientesMap.get(dono);
				String descricao = JOptionPane.showInputDialog(null, "Descricao do servico: ");
				Servicos servico01 = new Servicos(donos, cars, descricao, nmr);
				servico01.setData(JOptionPane.showInputDialog(null, "Digite a data do serviço: "));
	            servico01.AddMapaServ(servico01);

			 break;
		 case "4":
			 String nome = JOptionPane.showInputDialog(null, "Digite o nome da pessoa:");
			 Clientes pessoa =ClientesMap.get(nome);
			 if (pessoa != null) {
			     System.out.println("Nome: " + pessoa.getNome());
			     System.out.println("Numero: " + pessoa.getNumero());
			     System.out.println("Endereco: " + pessoa.getEndereco());
			 } else {
			     System.out.println("Não foi encontrada nenhuma pessoa com o nome '" + nome + "'");
			 }
			 break;
		 case"5":
			 String car = JOptionPane.showInputDialog(null, "Digite a Placa do carro:");
			 Carros carro =CarrosMap.get(car);
			 if (carro != null) {
			     System.out.println("Placa: " + carro.getPlaca());
			     System.out.println("Marca: " + carro.getMarca());
			     System.out.println("Modelo: " + carro.getModelo());
			     System.out.println("Ano: " + carro.getAno());
			     System.out.println("Dono: " + carro.getDono());
			 } else {
			     System.out.println("Não foi encontrada nenhum carro com a placa [" + car+ "]");
			 }break;
			 
	case"6":
     String nomeEdit = JOptionPane.showInputDialog(null, "Qual Cliente voce quer Adicionar dados: ");
      Clientes clienteedit =ClientesMap.get(nomeEdit);
		 if (clienteedit != null) {
		   String Dados = JOptionPane.showInputDialog(null,"Qual Dados voce quer editar?\n"
		   		+ "'Nome'\n"
		   		+ "'Telefone'\n"
		   		+ "'Endereco'\n");
		    switch(Dados) {
		    case "Nome":
		    String novonome=JOptionPane.showInputDialog(null, "Digite o novo nome do Cliente: ");
		    	clienteedit.setNome(novonome);
		    	System.out.println("O novo nome do cliente e: "+clienteedit.getNome());
		     break;
		       case "Telefone":
			    String novonmr=JOptionPane.showInputDialog(null, "Digite o novo numero do Cliente: ");
			    	clienteedit.setNumero(novonmr);
			    	System.out.println("O novo numero do cliente e: "+clienteedit.getNumero());
			    	break;
		        case "Endereco":
			    String novoend=JOptionPane.showInputDialog(null, "Digite o novo endereco do Cliente: ");
			    	clienteedit.setEndereco(novoend);
			    	System.out.println("O novo endereco do cliente e: "+clienteedit.getEndereco());
			      break;
			    	  default: System.out.print(" ");
			    		  }
			    	  break;}
		
		 case "7":
			 String carEdit = JOptionPane.showInputDialog(null, "Qual Veiculo voce quer Adicionar dados: ");
		      Carros caredit =CarrosMap.get(carEdit);
				 if (carEdit != null) {
				   String DadosCar = JOptionPane.showInputDialog(null,"Qual Dados voce quer editar?\n"
				   		+ "'Marca'\n"
				   		+ "'Modelo'\n"
				   		+ "'Ano'\n"
				   		+ "'Placa'\n"
				   		+ "'Dono'\n");
				   switch(DadosCar) {
				    case "Marca":
				    String novamarca=JOptionPane.showInputDialog(null, "Digite a Marca do carro: ");
				    	caredit.setMarca(novamarca);
				    	System.out.println("A Marca do carro agora e:"+caredit.getMarca());
				 break;
				 case "Modelo":
					 String novomodelo=JOptionPane.showInputDialog(null, "Digite o Modelo do carro: ");
				    	caredit.setModelo(novomodelo);
				    	System.out.println("O Modelo do carro agora e:"+caredit.getModelo());
				 break;
				 case "Ano":
					 String novoano=JOptionPane.showInputDialog(null, "Digite o Ano do carro: ");
				    	caredit.setAno(novoano);
				    	System.out.println("O Ano do carro agora e:"+caredit.getAno());
				 break;
				 case "Placa":
				 String novaplaca=JOptionPane.showInputDialog(null, "Digite a Placa do carro: ");
			    	caredit.setPlaca(novaplaca);
			    	System.out.println("A Placa do carro agora e:"+caredit.getPlaca());
			 break;
			 case "Dono":
				 String novodono=JOptionPane.showInputDialog(null, "Digite o Nome do Dono do carro: ");
			    	caredit.setDono(novodono);
			    	System.out.println("O Dono do carro agora e:"+caredit.getDono());
			    	break;
			    	default:System.out.println("Digite um dos dados acima! ");
				    }
				   }break;
		 case "8":
			 String cara = JOptionPane.showInputDialog(null, "Digite o numero do serviço:");
			 Servicos serv =ServicosMap.get(cara);
			 if (serv != null) {
			     System.out.println("Cliente: " + serv.getCliente());
			     System.out.println("Carro: " +  serv.getCarro());
			     System.out.println("Descricao: " + serv.getDescricao());
			     System.out.println("Data: " + serv.getData());
		
			 } else {
			     System.out.println("Não foi encontrada nenhum servico com o numero '" + cara + "'");
			 }
			 break;	   
		       case"9":
			       fim=4;
	              break;
	              default: System.out.print("Digite um valor acima");
		 }
	 }
	
 
 
 }}
	 
	 
 


	
	

