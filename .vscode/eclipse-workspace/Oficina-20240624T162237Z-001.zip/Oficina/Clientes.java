package Oficina;

import java.util.ArrayList;
import java.util.List;

public class Clientes {
private String nome;
private String Numero;
private String Endereco;

public String getNome() {
	return nome;
}
public void setNome(String nome) {
	this.nome = nome;
}
public String getNumero() {
	return Numero;
}
public void setNumero(String numero) {
	Numero = numero;
}
public String getEndereco() {
	return Endereco;
}
public void setEndereco(String endereco) {
	Endereco = endereco;
}

public Clientes(String nome) {
	this.nome=nome;
	
}

public void AddMapa(Clientes cliente) {
		Menu.ClientesMap.put(this.nome, cliente);}
	



public String toString() {
	return nome;
}
}
