package Oficina;

public class Servicos {
	private Clientes cliente;
	public Clientes getCliente() {
		return cliente;
	}

	public void setCliente(Clientes cliente) {
		this.cliente = cliente;
	}

	public Carros getCarro() {
		return carro;
	}

	public void setCarro(Carros carro) {
		this.carro = carro;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getNumeroservico() {
		return numeroservico;
	}

	public void setNumeroservico(String numeroservico) {
		this.numeroservico = numeroservico;
	}

	public String getData() {
		return data;
	}


	private Carros carro;
	private String descricao;
	private String data;
private String numeroservico;
public Servicos(Clientes cliente, Carros carro, String descricao, String nmr) {
	this.cliente = cliente;
	this.carro=carro;
	this.descricao=descricao;
	this.numeroservico = nmr;
}

public void setData(String data) {
	this.data=data;
}
public String getServicos() {
	return cliente+", "+carro+", \n"+"descricao: "+descricao;
}
public void AddMapaServ(Servicos carro) {
	Menu.ServicosMap.put(this.numeroservico, carro);}


public String toString() {
	return this.carro + ", "+this.cliente;
}
}
